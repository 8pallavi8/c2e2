import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { dateInputsHaveChanged } from '@angular/material/datepicker/datepicker-input-base';
import { DistTransformer } from 'src/app/shared/models/models';
import { ToolsService } from 'src/app/shared/services/tools.service';

export interface FinalTable {
  efficacy?: number;
  ll?: number;
  nl?: number;
  energyeffyincrease?: number;
  energy?: number;
  financial?: number;
  paybackperiod?: number;
  co2baseline?: number;
  co2savingston?: number;
  co2savingspercent?: number;
  finalco2emissions?: number;
}

export interface PieArray {
  label?: string;
  value?: number;
}

@Component({
  selector: 'app-dis-transformer',
  templateUrl: './distribution-transformer.component.html',
  styleUrls: ['./distribution-transformer.component.scss']
})
export class DisTransformerComponent implements OnInit {
  showForms: boolean = true;
  DisTransformerInputs: FormGroup;
  forminputs: FormArray;
  InputValuesArr: DistTransformer[] = [];
  policyLevels: number[] = [1, 2];
  FireRegulation: String[] = ["Fire standard distribution power transformers", "Fire safer distribution power transformers"];
  submitted: boolean;
  errMessage: string;
  dataSource: any;
  countrylist: String[];
  highestVoltageValueslist: String[];
  dualVoltWindings: String[];
  displayedColumns: string[] = [
    'efficacy',
    'll',
    'nl',
    'energyeffyincrease',
    'energy',
    'financial',
    'paybackperiod',
    'co2baseline',
    'co2savingston',
    'co2savingspercent',
    'finalco2emissions'
  ];
  pieArray: PieArray[] =[];

  


  
  constructor(private fb: FormBuilder, private toolService: ToolsService) { }

  ngOnInit(): void {
    this.toolService.getTool1Inputs().subscribe(res => {
      console.log(res.Countries);
      this.countrylist = res.Countries;
      this.highestVoltageValueslist = res.HighestVoltageValues;
      this.dualVoltWindings = res.DualVoltWindings;
      console.log(this.highestVoltageValueslist);
    })

    this.DisTransformerInputs = this.fb.group({
      Country: ['', Validators.compose([Validators.required])],
      forminputs: this.fb.array([this.createVariant()])
    });
    
  }

  createVariant(): FormGroup {
    return this.fb.group({
      Power: ['', Validators.compose([Validators.required])],
      Stock: ['', Validators.compose([Validators.required])],
      PlateEfficiency: ['', Validators.compose([Validators.required])],
      Energy: ['', Validators.compose([Validators.required])],
      EnergyPrice: ['', Validators.compose([Validators.required])],
      PolicyLevel: ['', Validators.compose([Validators.required])],
      FireRegulation: ['', Validators.compose([Validators.required])],
      HighestVoltageValues: ['', Validators.compose([Validators.required])],
      DualVoltWindings: ['', Validators.compose([Validators.required])],
      Capex: ['', Validators.compose([Validators.required])],
    });
  }

  addTransformerVariant(): void {
    this.forminputs = this.DisTransformerInputs.get('forminputs') as FormArray;
    if ((<FormArray>this.DisTransformerInputs.get('forminputs')).length <= 10) {
      this.forminputs.push(this.createVariant());
    } else {
      this.errMessage = 'Can not exceed 10 Inputs'
    }

    console.log(this.DisTransformerInputs);
  }

  removeVariant(index): void {
    this.forminputs.removeAt(index);
    console.log(this.forminputs);
  }

  addNewTransformerVariant() {
    console.log('form value: ', (<FormArray>this.DisTransformerInputs.get('forminputs')).length);
    this.InputValuesArr = [];
    if (this.DisTransformerInputs.valid) {
      for (let i = 0; i < (<FormArray>this.DisTransformerInputs.get('forminputs')).length; i++) {
        console.log((<FormGroup>(<FormArray>this.DisTransformerInputs.get('forminputs')).controls[i]).value);
        var formInput: DistTransformer = {
          Requestnumber: i + 1,
          Power: (<FormGroup>(<FormArray>this.DisTransformerInputs.get('forminputs')).controls[i]).controls.Power.value,
          Stock: (<FormGroup>(<FormArray>this.DisTransformerInputs.get('forminputs')).controls[i]).controls.Stock.value,
          PlateEfficiency: (<FormGroup>(<FormArray>this.DisTransformerInputs.get('forminputs')).controls[i]).controls.PlateEfficiency.value,
          Energy: (<FormGroup>(<FormArray>this.DisTransformerInputs.get('forminputs')).controls[i]).controls.Energy.value,
          EnergyPrice: (<FormGroup>(<FormArray>this.DisTransformerInputs.get('forminputs')).controls[i]).controls.EnergyPrice.value,
          PolicyLevel: (<FormGroup>(<FormArray>this.DisTransformerInputs.get('forminputs')).controls[i]).controls.PolicyLevel.value,
          FireRegulation: (<FormGroup>(<FormArray>this.DisTransformerInputs.get('forminputs')).controls[i]).controls.FireRegulation.value,
          HighestVoltageValues: (<FormGroup>(<FormArray>this.DisTransformerInputs.get('forminputs')).controls[i]).controls.HighestVoltageValues.value,
          DualVoltWindings: (<FormGroup>(<FormArray>this.DisTransformerInputs.get('forminputs')).controls[i]).controls.DualVoltWindings.value,
          Capex: (<FormGroup>(<FormArray>this.DisTransformerInputs.get('forminputs')).controls[i]).controls.Capex.value
        }
        this.InputValuesArr.push(formInput);
      }
      var transReq = {
        ReqTimeStamp: Date.now(),
        Country: this.DisTransformerInputs.get('Country').value,
        InputValuesArr: this.InputValuesArr
      }

      this.toolService.sendDisTransformerDetails(transReq).subscribe(res => {
        console.log(res);
        if (res.status == 'success') {
          var finalOutValues: FinalTable[] = [];
          res.success.finalvalues.forEach(ele => {
            console.log(ele);
            finalOutValues.push(ele);
          });
          finalOutValues.push({
            efficacy: res.success.totalfinalvalues.totalefficacy,
            ll: res.success.totalfinalvalues.totalll,
            nl: res.success.totalfinalvalues.totalnl,
            energyeffyincrease: res.success.totalfinalvalues.totalenergyeffyincrease,
            energy: res.success.totalfinalvalues.totalenergy,
            financial: res.success.totalfinalvalues.totalfinancial,
            paybackperiod: res.success.totalfinalvalues.totalpaybackperiod,
            co2baseline: res.success.totalfinalvalues.totalco2baseline,
            co2savingston: res.success.totalfinalvalues.totalco2savingston,
            co2savingspercent: res.success.totalfinalvalues.totalco2savingspercent,
            finalco2emissions: res.success.totalfinalvalues.totalfinalco2emissions,
          });
          this.dataSource = finalOutValues;
          for (let i = 0; i < finalOutValues.length - 1; i++) {
            var calEnergy = (finalOutValues[i].energy / finalOutValues[finalOutValues.length - 1].energy) * 100;
            this.pieArray.push({
              label: 'E' + i,
              value: Math.round(calEnergy * 100) / 100
            });
          }
          console.log(this.dataSource, this.pieArray);
          
          //console.log(this.dataSource);
          this.showForms = false;
        } else {
          this.showForms = true;
        }
      });
      //console.log(this.InputValuesArr);
    } else {
      this.submitted = true;
    }
  }


}