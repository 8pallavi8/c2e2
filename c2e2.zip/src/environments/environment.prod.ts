export const environment = {
  production: true,
  baseUrl: ' http://clicked2help.in:9999/api/v1/tool1',
  inputUrl:' http://clicked2help.in:9999/api/v1/getddvalues'
};
