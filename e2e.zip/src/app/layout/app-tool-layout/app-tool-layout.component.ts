import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-tool-layout',
  templateUrl: './app-tool-layout.component.html',
  styleUrls: ['./app-tool-layout.component.scss']
})
export class AppToolLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
