import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-street-light',
  templateUrl: './street-light.component.html',
  styleUrls: ['./street-light.component.scss']
})
export class StreetLightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
