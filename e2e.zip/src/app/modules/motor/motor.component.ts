import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-motor',
  templateUrl: './motor.component.html',
  styleUrls: ['./motor.component.scss']
})
export class MotorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
