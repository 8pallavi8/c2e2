import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-motor-pump',
  templateUrl: './motor-pump.component.html',
  styleUrls: ['./motor-pump.component.scss']
})
export class MotorPumpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
