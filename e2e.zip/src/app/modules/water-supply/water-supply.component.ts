import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-water-supply',
  templateUrl: './water-supply.component.html',
  styleUrls: ['./water-supply.component.scss']
})
export class WaterSupplyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
