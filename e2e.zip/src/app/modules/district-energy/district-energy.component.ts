import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-district-energy',
  templateUrl: './district-energy.component.html',
  styleUrls: ['./district-energy.component.scss']
})
export class DistrictEnergyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
