export const environment = {
  production: true,
  baseUrl: 'http://clicked2help.in',
};
